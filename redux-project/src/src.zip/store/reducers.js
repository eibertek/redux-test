const initialState = {

}

export const NOCASE = "[ROOT][CASE] there no case";
export const LOAD_CARD_PENDING = "[CARD][LOAD] LOAD Action pending";
export const LOAD_CARD_SUCCESS = "[CARD][LOAD] LOAD Action SUccess";
export const LOAD_CARD_FAILURE = "load card failure";


export default (state = initialState, action) => {
  switch (action.type) {
    case LOAD_CARD_PENDING:
        return { ...state, card: action.card }
    case NOCASE:
        return { ...state }

  default:
    return state;
  }
}
