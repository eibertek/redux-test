import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import store from './store';
import { Provider } from "react-redux";
import registerServiceWorker from './registerServiceWorker';
import { LOAD_CARD_PENDING } from './store/reducers';

store.dispatch({ type: LOAD_CARD_PENDING, card: { id: '1',} });

ReactDOM.render(<Provider>
    <App store={store} />
</Provider>, document.getElementById('root'));
registerServiceWorker();
